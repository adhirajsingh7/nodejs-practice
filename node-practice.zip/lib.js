exports.sum = (a,b)=>{
    return a+b;
}

exports.diff = (a,b)=>{
    return a-b;
}