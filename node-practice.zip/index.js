const lib = require('./lib.js');


const express = require('express');

const server = express();

console.log('hello world')

server.listen(8080);


// import {sum,diff} from './lib.js'


// const fs = require('fs');

// const txt = fs.readFileSync('demo.txt','utf-8');

// const t1 = performance.now();

// fs.readFile('demo.txt','utf-8',(err, txt)=>{
//     console.log(txt);
// });
// console.log(txt);

// const t2 = performance.now()

//  console.log(lib.sum(3,5),lib.diff(10,8));

//  console.log(t2-t1);